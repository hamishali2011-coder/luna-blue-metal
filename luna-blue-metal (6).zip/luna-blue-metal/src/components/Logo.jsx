import { Link } from 'react-router-dom'

/**
 * The Crescent Bloom logo — a hand-illustrated badge (crescent moon, star
 * charm, and a pipe-cleaner floral bouquet) that already contains the full
 * wordmark and tagline, so it's used on its own without extra text.
 */
export default function Logo({ dark = false, className = '', size = 'md' }) {
  const dimensions = size === 'lg' ? 'h-16 w-16' : 'h-11 w-11'
  return (
    <Link to="/" className={`inline-flex items-center gap-2.5 group ${className}`} aria-label="The Crescent Bloom home">
      <img
        src="/logo.jpeg"
        alt="The Crescent Bloom"
        className={`${dimensions} rounded-full object-cover shrink-0 transition-transform duration-500 group-hover:-rotate-6 ${dark ? 'ring-1 ring-white/20' : ''}`}
      />
    </Link>
  )
}
